"""
Вспомогательные функции
"""

def format_phone(phone: str) -> str:
    """Форматировать номер телефона"""
    phone_clean = phone.replace("+", "").replace("-", "").replace(" ", "").replace("(", "").replace(")", "")
    if phone_clean.startswith("8") and len(phone_clean) == 11:
        phone_clean = "7" + phone_clean[1:]
    if not phone_clean.startswith("+"):
        phone_clean = "+" + phone_clean
    return phone_clean

