"""Скрипт для проверки подключения к базе данных"""
import asyncio
import asyncpg
from config import DB_CONFIG

async def test_connection():
    print("Проверка подключения к базе данных...")
    print(f"Host: {DB_CONFIG['host']}")
    print(f"Port: {DB_CONFIG['port']}")
    print(f"Database: {DB_CONFIG['database']}")
    print(f"User: {DB_CONFIG['user']}")
    print()
    
    try:
        print("Попытка подключения...")
        conn = await asyncpg.connect(**DB_CONFIG)
        print("✅ Подключение успешно!")
        
        # Проверить версию PostgreSQL
        version = await conn.fetchval('SELECT version()')
        print(f"\nВерсия PostgreSQL: {version.split(',')[0]}")
        
        await conn.close()
        print("\n✅ Все проверки пройдены успешно!")
        return True
        
    except asyncpg.InvalidPasswordError:
        print("❌ Ошибка: Неверный пароль!")
        print("   Проверьте пароль в файле .env")
        return False
        
    except asyncpg.InvalidCatalogNameError:
        print(f"❌ Ошибка: База данных '{DB_CONFIG['database']}' не существует!")
        print(f"   Создайте базу данных командой:")
        print(f"   CREATE DATABASE {DB_CONFIG['database']};")
        return False
        
    except asyncpg.InvalidAuthorizationSpecificationError:
        print(f"❌ Ошибка: Пользователь '{DB_CONFIG['user']}' не существует!")
        print(f"   Создайте пользователя в PostgreSQL или используйте 'postgres'")
        return False
        
    except ConnectionRefusedError:
        print("❌ Ошибка: Не удалось подключиться к серверу!")
        print("   Убедитесь, что PostgreSQL запущен")
        print("   Проверьте, что порт 5432 открыт")
        return False
        
    except Exception as e:
        print(f"❌ Ошибка подключения: {e}")
        print(f"\nТип ошибки: {type(e).__name__}")
        return False

if __name__ == "__main__":
    try:
        result = asyncio.run(test_connection())
        if not result:
            print("\n" + "="*50)
            print("См. файл РЕШЕНИЕ_ОШИБОК_БД.md для подробных инструкций")
    except KeyboardInterrupt:
        print("\n\nПрервано пользователем")

