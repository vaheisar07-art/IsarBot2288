from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from typing import List, Dict


def get_main_menu() -> InlineKeyboardMarkup:
    """Главное меню бота"""
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛍 Каталог товаров", callback_data="catalog")],
        [InlineKeyboardButton(text="📦 Мои заказы", callback_data="my_orders")],
        [InlineKeyboardButton(text="⭐ Отзывы", callback_data="reviews")],
        [InlineKeyboardButton(text="💬 Поддержка", callback_data="support")],
        [InlineKeyboardButton(text="📢 Наш телеграм канал", url="https://t.me/moqxmshop")]
    ])
    return keyboard


def get_catalog_keyboard(products: List[Dict]) -> InlineKeyboardMarkup:
    """Клавиатура каталога товаров"""
    buttons = []
    for product in products:
        buttons.append([
            InlineKeyboardButton(
                text=f"{product['name']} - {product['price']}₽",
                callback_data=f"buy_{product['id']}"
            )
        ])
    buttons.append([InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_menu")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def get_product_keyboard(product_id: int) -> InlineKeyboardMarkup:
    """Клавиатура для товара"""
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💰 Купить", callback_data=f"buy_{product_id}")],
        [InlineKeyboardButton(text="🔙 Назад в каталог", callback_data="catalog")]
    ])
    return keyboard


def get_cancel_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура отмены действия"""
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Отмена", callback_data="cancel")]
    ])
    return keyboard


def get_admin_menu() -> InlineKeyboardMarkup:
    """Админ-панель"""
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⏳ Заказы ожидающие оплаты", callback_data="admin_pending_orders")],
        [InlineKeyboardButton(text="📋 Все заказы", callback_data="admin_all_orders")],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_menu")]
    ])
    return keyboard


def get_order_keyboard(order_id: int) -> InlineKeyboardMarkup:
    """Клавиатура для заказа в админ-панели"""
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Подтвердить оплату", callback_data=f"admin_confirm_{order_id}")],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="admin_pending_orders")]
    ])
    return keyboard


def get_orders_list_keyboard(orders: List[Dict], is_admin: bool = False) -> InlineKeyboardMarkup:
    """Клавиатура со списком заказов"""
    buttons = []
    for order in orders:
        status_emoji = {
            "pending": "⏳",
            "paid": "✅",
            "completed": "🎉",
            "cancelled": "❌"
        }.get(order['status'], "❓")
        
        prefix = "admin_order_" if is_admin else "order_"
        buttons.append([
            InlineKeyboardButton(
                text=f"{status_emoji} Заказ #{order['id']} - {status_emoji}",
                callback_data=f"{prefix}{order['id']}"
            )
        ])
    
    callback_back = "admin_menu" if is_admin else "back_to_menu"
    buttons.append([InlineKeyboardButton(text="🔙 Назад", callback_data=callback_back)])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def get_reviews_keyboard(can_add_review: bool = False) -> InlineKeyboardMarkup:
    """Клавиатура для отзывов"""
    buttons = []
    if can_add_review:
        buttons.append([InlineKeyboardButton(text="➕ Добавить отзыв", callback_data="add_review")])
    buttons.append([InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_menu")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def get_rating_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура для выбора оценки"""
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="⭐", callback_data="rating_1"),
            InlineKeyboardButton(text="⭐⭐", callback_data="rating_2"),
            InlineKeyboardButton(text="⭐⭐⭐", callback_data="rating_3"),
            InlineKeyboardButton(text="⭐⭐⭐⭐", callback_data="rating_4"),
            InlineKeyboardButton(text="⭐⭐⭐⭐⭐", callback_data="rating_5"),
        ],
        [InlineKeyboardButton(text="❌ Отмена", callback_data="cancel")]
    ])
    return keyboard

