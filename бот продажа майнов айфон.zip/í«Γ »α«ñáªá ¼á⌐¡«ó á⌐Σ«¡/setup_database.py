"""Скрипт для создания базы данных и пользователя"""
import asyncio
import asyncpg
from config import DB_CONFIG

async def setup_database():
    """Создание базы данных и пользователя"""
    try:
        print("Подключение к PostgreSQL...")
        # Подключаемся к системной базе данных postgres
        conn = await asyncpg.connect(
            host="localhost",
            port=5432,
            database="postgres",
            user="postgres",
            password="sas123"  # Пароль из .env
        )
        print("✅ Подключение успешно!\n")
        
        db_name = DB_CONFIG['database']
        db_user = DB_CONFIG['user']
        db_password = DB_CONFIG['password']
        
        # Проверяем существование базы данных
        db_exists = await conn.fetchval(
            "SELECT 1 FROM pg_database WHERE datname = $1",
            db_name
        )
        
        if db_exists:
            print(f"✅ База данных '{db_name}' уже существует")
        else:
            print(f"Создание базы данных '{db_name}'...")
            await conn.execute(f'CREATE DATABASE "{db_name}"')
            print(f"✅ База данных '{db_name}' создана")
        
        # Проверяем существование пользователя
        user_exists = await conn.fetchval(
            "SELECT 1 FROM pg_user WHERE usename = $1",
            db_user
        )
        
        if user_exists:
            print(f"✅ Пользователь '{db_user}' уже существует")
            # Обновляем пароль (используем quote_ident и quote_literal для безопасности)
            print(f"Обновление пароля для пользователя '{db_user}'...")
            password_escaped = db_password.replace("'", "''")  # Экранируем одинарные кавычки
            await conn.execute(f'ALTER USER "{db_user}" WITH PASSWORD \'{password_escaped}\'')
            print(f"✅ Пароль обновлен")
        else:
            print(f"Создание пользователя '{db_user}'...")
            password_escaped = db_password.replace("'", "''")  # Экранируем одинарные кавычки
            await conn.execute(f'CREATE USER "{db_user}" WITH PASSWORD \'{password_escaped}\'')
            print(f"✅ Пользователь '{db_user}' создан")
        
        # Выдаем права на базу данных
        print(f"Выдача прав пользователю '{db_user}' на базу данных '{db_name}'...")
        await conn.execute(f'GRANT ALL PRIVILEGES ON DATABASE "{db_name}" TO "{db_user}"')
        print(f"✅ Права выданы")
        
        await conn.close()
        
        # Подключаемся к созданной базе данных для выдачи прав на схему
        print(f"\nПодключение к базе данных '{db_name}'...")
        conn_new = await asyncpg.connect(
            host="localhost",
            port=5432,
            database=db_name,
            user="postgres",
            password="sas123"
        )
        
        # Выдаем права на схему public
        print("Выдача прав на схему public...")
        await conn_new.execute(f'GRANT ALL ON SCHEMA public TO "{db_user}"')
        await conn_new.execute(f'GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO "{db_user}"')
        await conn_new.execute(f'GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO "{db_user}"')
        await conn_new.execute(f'ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO "{db_user}"')
        await conn_new.execute(f'ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO "{db_user}"')
        print("✅ Права на схему выданы")
        
        await conn_new.close()
        
        print("\n" + "="*50)
        print("✅ База данных настроена успешно!")
        print("="*50)
        print("\nТеперь можно запустить бота: python main.py")
        
    except asyncpg.InvalidPasswordError:
        print("❌ Ошибка: Неверный пароль для пользователя 'postgres'")
        print("   Укажите правильный пароль в скрипте (строка 12)")
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        print(f"   Тип: {type(e).__name__}")

if __name__ == "__main__":
    try:
        asyncio.run(setup_database())
    except KeyboardInterrupt:
        print("\n\nПрервано пользователем")

