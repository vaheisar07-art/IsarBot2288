"""Проверка подключения с пользователем postgres"""
import asyncio
import asyncpg

async def test_postgres_user():
    """Проверка подключения с пользователем postgres"""
    try:
        print("Попытка подключения с пользователем 'postgres'...")
        conn = await asyncpg.connect(
            host="localhost",
            port=5432,
            database="postgres",  # Системная база данных
            user="postgres",
            password="sas123"  # Попробуем тот же пароль
        )
        print("✅ Подключение с 'postgres' успешно!")
        
        # Проверим существование базы данных
        db_exists = await conn.fetchval(
            "SELECT 1 FROM pg_database WHERE datname = $1",
            "minecraft_bot"
        )
        
        if db_exists:
            print("✅ База данных 'minecraft_bot' существует")
        else:
            print("❌ База данных 'minecraft_bot' НЕ существует")
            print("   Нужно создать базу данных")
        
        # Проверим существование пользователя
        user_exists = await conn.fetchval(
            "SELECT 1 FROM pg_user WHERE usename = $1",
            "MineforiphoneBot"
        )
        
        if user_exists:
            print("✅ Пользователь 'MineforiphoneBot' существует")
        else:
            print("❌ Пользователь 'MineforiphoneBot' НЕ существует")
            print("   Нужно создать пользователя")
        
        await conn.close()
        
    except asyncpg.InvalidPasswordError:
        print("❌ Неверный пароль для пользователя 'postgres'")
        print("   Используйте пароль, который вы указали при установке PostgreSQL")
    except Exception as e:
        print(f"❌ Ошибка: {e}")

if __name__ == "__main__":
    asyncio.run(test_postgres_user())

