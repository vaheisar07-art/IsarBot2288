import asyncpg
import asyncio
from datetime import datetime
from typing import Optional, List, Dict
from config import DB_CONFIG


class Database:
    _pool: Optional[asyncpg.Pool] = None

    @classmethod
    async def get_pool(cls):
        """Получить пул подключений к БД"""
        if cls._pool is None:
            try:
                cls._pool = await asyncpg.create_pool(**DB_CONFIG)
            except Exception as e:
                print(f"❌ Ошибка подключения к базе данных: {e}")
                print(f"Проверьте настройки в .env файле:")
                print(f"  DB_HOST={DB_CONFIG['host']}")
                print(f"  DB_PORT={DB_CONFIG['port']}")
                print(f"  DB_NAME={DB_CONFIG['database']}")
                print(f"  DB_USER={DB_CONFIG['user']}")
                print(f"  DB_PASSWORD={'*' * len(DB_CONFIG['password']) if DB_CONFIG['password'] else '(пусто)'}")
                raise
        return cls._pool

    @classmethod
    async def init_db(cls):
        """Инициализация базы данных - создание таблиц"""
        pool = await cls.get_pool()

        async with pool.acquire() as conn:
            # Таблица пользователей
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id BIGINT PRIMARY KEY,
                    username TEXT,
                    full_name TEXT,
                    is_admin BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMP DEFAULT NOW()
                )
            """)

            # Таблица товаров
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS products (
                    id SERIAL PRIMARY KEY,
                    name TEXT NOT NULL,
                    description TEXT,
                    price INTEGER NOT NULL,
                    credentials TEXT NOT NULL,
                    is_active BOOLEAN DEFAULT TRUE,
                    created_at TIMESTAMP DEFAULT NOW()
                )
            """)

            # Таблица заказов
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS orders (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT NOT NULL REFERENCES users(id),
                    product_id INTEGER NOT NULL REFERENCES products(id),
                    status TEXT DEFAULT 'pending',
                    phone_number TEXT,
                    created_at TIMESTAMP DEFAULT NOW(),
                    paid_at TIMESTAMP,
                    completed_at TIMESTAMP
                )
            """)

            # Таблица отзывов
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS reviews (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT NOT NULL REFERENCES users(id),
                    text TEXT NOT NULL,
                    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
                    created_at TIMESTAMP DEFAULT NOW()
                )
            """)

            # Таблица логов админов
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS admin_logs (
                    id SERIAL PRIMARY KEY,
                    admin_id BIGINT NOT NULL REFERENCES users(id),
                    action TEXT NOT NULL,
                    order_id INTEGER REFERENCES orders(id),
                    created_at TIMESTAMP DEFAULT NOW()
                )
            """)

            print("✅ База данных инициализирована")

    @classmethod
    async def close(cls):
        """Закрыть пул подключений"""
        if cls._pool:
            await cls._pool.close()

    # Работа с пользователями
    @staticmethod
    async def get_or_create_user(user_id: int, username: str = None, full_name: str = None) -> Dict:
        """Получить пользователя или создать нового"""
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            user = await conn.fetchrow(
                "SELECT * FROM users WHERE id = $1", user_id
            )
            
            if user:
                # Обновить username и full_name если изменились
                await conn.execute(
                    "UPDATE users SET username = $1, full_name = $2 WHERE id = $3",
                    username, full_name, user_id
                )
                return dict(user)
            else:
                # Проверить, является ли админом по ID из конфига
                is_admin = user_id in (await Database.get_admin_ids())
                await conn.execute(
                    "INSERT INTO users (id, username, full_name, is_admin) VALUES ($1, $2, $3, $4)",
                    user_id, username, full_name, is_admin
                )
                new_user = await conn.fetchrow(
                    "SELECT * FROM users WHERE id = $1", user_id
                )
                return dict(new_user)

    @staticmethod
    async def get_admin_ids() -> List[int]:
        """Получить список ID администраторов"""
        from config import ADMIN_IDS
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            admin_rows = await conn.fetch("SELECT id FROM users WHERE is_admin = TRUE")
            admin_ids = [row['id'] for row in admin_rows]
            # Добавить админов из конфига
            admin_ids.extend(ADMIN_IDS)
            return list(set(admin_ids))  # Убрать дубликаты

    @staticmethod
    async def is_admin(user_id: int) -> bool:
        """Проверить, является ли пользователь админом"""
        admin_ids = await Database.get_admin_ids()
        return user_id in admin_ids

    # Работа с товарами
    @staticmethod
    async def get_products() -> List[Dict]:
        """Получить все активные товары"""
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM products WHERE is_active = TRUE ORDER BY id")
            return [dict(row) for row in rows]

    @staticmethod
    async def get_product(product_id: int) -> Optional[Dict]:
        """Получить товар по ID"""
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM products WHERE id = $1", product_id)
            return dict(row) if row else None

    # Работа с заказами
    @staticmethod
    async def create_order(user_id: int, product_id: int, phone_number: str) -> Dict:
        """Создать новый заказ"""
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                INSERT INTO orders (user_id, product_id, phone_number, status)
                VALUES ($1, $2, $3, 'pending')
                RETURNING *
            """, user_id, product_id, phone_number)
            return dict(row)

    @staticmethod
    async def get_order(order_id: int) -> Optional[Dict]:
        """Получить заказ по ID"""
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM orders WHERE id = $1", order_id)
            return dict(row) if row else None

    @staticmethod
    async def get_user_orders(user_id: int) -> List[Dict]:
        """Получить заказы пользователя"""
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM orders WHERE user_id = $1 ORDER BY created_at DESC",
                user_id
            )
            return [dict(row) for row in rows]

    @staticmethod
    async def get_pending_orders() -> List[Dict]:
        """Получить заказы ожидающие оплаты"""
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM orders WHERE status = 'pending' ORDER BY created_at DESC"
            )
            return [dict(row) for row in rows]

    @staticmethod
    async def get_all_orders() -> List[Dict]:
        """Получить все заказы"""
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM orders ORDER BY created_at DESC LIMIT 50"
            )
            return [dict(row) for row in rows]

    @staticmethod
    async def confirm_payment(order_id: int, admin_id: int) -> bool:
        """Подтвердить оплату и отправить данные"""
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            # Обновить статус заказа
            await conn.execute("""
                UPDATE orders 
                SET status = 'paid', paid_at = NOW(), completed_at = NOW()
                WHERE id = $1
            """, order_id)

            # Добавить запись в логи
            await conn.execute("""
                INSERT INTO admin_logs (admin_id, action, order_id)
                VALUES ($1, 'confirm_payment', $2)
            """, admin_id, order_id)

            return True

    @staticmethod
    async def complete_order(order_id: int):
        """Отметить заказ как выполненный"""
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            await conn.execute("""
                UPDATE orders SET status = 'completed', completed_at = NOW()
                WHERE id = $1
            """, order_id)

    # Работа с отзывами
    @staticmethod
    async def get_reviews(limit: int = 10) -> List[Dict]:
        """Получить последние отзывы"""
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT r.*, u.username, u.full_name
                FROM reviews r
                JOIN users u ON r.user_id = u.id
                ORDER BY r.created_at DESC
                LIMIT $1
            """, limit)
            return [dict(row) for row in rows]

    @staticmethod
    async def create_review(user_id: int, text: str, rating: int) -> Dict:
        """Создать отзыв"""
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                INSERT INTO reviews (user_id, text, rating)
                VALUES ($1, $2, $3)
                RETURNING *
            """, user_id, text, rating)
            return dict(row)

    @staticmethod
    async def has_user_bought(user_id: int) -> bool:
        """Проверить, покупал ли пользователь что-то"""
        pool = await Database.get_pool()
        async with pool.acquire() as conn:
            count = await conn.fetchval(
                "SELECT COUNT(*) FROM orders WHERE user_id = $1 AND status IN ('paid', 'completed')",
                user_id
            )
            return count > 0

