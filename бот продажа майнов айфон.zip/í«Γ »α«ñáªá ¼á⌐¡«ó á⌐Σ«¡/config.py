import os
from dotenv import load_dotenv

load_dotenv()

# Токен бота от @BotFather
BOT_TOKEN = os.getenv("BOT_TOKEN")

# Настройки базы данных PostgreSQL
db_password = os.getenv("DB_PASSWORD", "")
# Если пароль содержит "ваш_пароль" (заглушку), заменить на пустую строку
if "ваш_пароль" in db_password.lower() or "пароль" in db_password.lower():
    db_password = ""
    
# Получить имя пользователя и убрать @ если есть (PostgreSQL не поддерживает @ в именах)
db_user = os.getenv("DB_USER", "postgres").lstrip("@")

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", 5432)),
    "database": os.getenv("DB_NAME", "minecraft_bot"),
    "user": db_user,
    "password": db_password,
}

# ID администраторов (через запятую в .env)
ADMIN_IDS = []
admin_ids_str = os.getenv("ADMIN_IDS", "")
if admin_ids_str:
    for admin_id in admin_ids_str.split(","):
        admin_id = admin_id.strip()
        if admin_id and admin_id != "ваш_telegram_id":
            try:
                ADMIN_IDS.append(int(admin_id))
            except ValueError:
                print(f"Предупреждение: некорректный ADMIN_ID '{admin_id}' пропущен")

# Текст приветствия
WELCOME_TEXT = """
🎮 <b>Добро пожаловать в бот продажи Minecraft на iOS!</b>

📱 Мы предлагаем доступ к общему аккаунту App Store для скачивания игр:
• Minecraft - 49₽
• Terraria - 49₽
• Geometry Dash - 49₽
• FNAF 2 - 49₽

💳 <b>Способ оплаты:</b> Перевод по номеру телефона

✅ После подтверждения оплаты вы получите данные аккаунта для входа в App Store и скачивания игр.

Выберите действие в меню ниже 👇
"""

