import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from config import BOT_TOKEN
from database import Database
from handlers import start, catalog, orders, admin, support, reviews

# Создаем экземпляр бота и диспетчера
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


async def on_startup():
    """Действия при запуске бота"""
    logger.info("Бот запускается...")
    
    # Инициализация базы данных
    await Database.init_db()
    
    # Добавить товары если их нет
    await add_default_products()
    
    logger.info("✅ Бот готов к работе!")


async def add_default_products():
    """Добавить товары по умолчанию, если их нет"""
    pool = await Database.get_pool()
    async with pool.acquire() as conn:
        count = await conn.fetchval("SELECT COUNT(*) FROM products")
        
        if count == 0:
            products = [
                {
                    "name": "Minecraft",
                    "description": "Доступ к аккаунту App Store для скачивания Minecraft",
                    "price": 49,
                    "credentials": "Email: minecraft@example.com\nПароль: Password123"
                },
                {
                    "name": "Terraria",
                    "description": "Доступ к аккаунту App Store для скачивания Terraria",
                    "price": 49,
                    "credentials": "Email: terraria@example.com\nПароль: Password123"
                },
                {
                    "name": "Geometry Dash",
                    "description": "Доступ к аккаунту App Store для скачивания Geometry Dash",
                    "price": 49,
                    "credentials": "Email: geometry@example.com\nПароль: Password123"
                },
                {
                    "name": "FNAF 2",
                    "description": "Доступ к аккаунту App Store для скачивания Five Nights at Freddy's 2",
                    "price": 49,
                    "credentials": "Email: fnaf2@example.com\nПароль: Password123"
                }
            ]
            
            for product in products:
                await conn.execute("""
                    INSERT INTO products (name, description, price, credentials)
                    VALUES ($1, $2, $3, $4)
                """, product["name"], product["description"], product["price"], product["credentials"])
            
            logger.info(f"✅ Добавлено {len(products)} товаров по умолчанию")
        else:
            logger.info(f"✅ В базе уже есть {count} товаров")


def register_handlers():
    """Регистрация всех handlers"""
    dp.include_router(start.router)
    dp.include_router(catalog.router)
    dp.include_router(orders.router)
    dp.include_router(admin.router)
    dp.include_router(support.router)
    dp.include_router(reviews.router)


async def main():
    """Главная функция"""
    try:
        # Регистрация handlers
        register_handlers()
        
        # Действия при запуске
        await on_startup()
        
        # Запуск polling
        await dp.start_polling(bot, skip_updates=True)
        
    except Exception as e:
        logger.error(f"Ошибка: {e}")
    finally:
        await Database.close()
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Бот остановлен пользователем")

