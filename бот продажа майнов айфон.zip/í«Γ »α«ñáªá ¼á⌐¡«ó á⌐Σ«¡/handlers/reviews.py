from aiogram import Router, F
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from database import Database
from keyboards import get_reviews_keyboard, get_rating_keyboard, get_main_menu, get_cancel_keyboard

router = Router()


class ReviewStates(StatesGroup):
    waiting_rating = State()
    waiting_text = State()


@router.callback_query(F.data == "reviews")
async def show_reviews(callback: CallbackQuery):
    """Показать отзывы"""
    await callback.answer()
    
    text = (
        "⭐ <b>Отзывы</b>\n\n"
        "📝 Все отзывы наших покупателей вы можете посмотреть в нашем канале с отзывами!\n\n"
        "👉 Переходите по ссылке ниже, чтобы увидеть реальные отзывы от довольных клиентов.\n\n"
        "💬 Там вы найдете:\n"
        "• Реальные отзывы покупателей\n"
        "• Скриншоты и фото\n"
        "• Оценки и комментарии\n"
        "• Истории успешных покупок"
    )
    
    # Клавиатура с кнопкой на канал отзывов
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📢 Перейти к отзывам", url="https://t.me/iwiwicjzis")],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_menu")]
    ])
    
    await callback.message.edit_text(
        text,
        reply_markup=keyboard,
        parse_mode="HTML"
    )


@router.callback_query(F.data == "add_review")
async def start_add_review(callback: CallbackQuery, state: FSMContext):
    """Начать добавление отзыва"""
    await callback.answer()
    
    # Проверить, может ли пользователь оставить отзыв
    user_id = callback.from_user.id
    has_bought = await Database.has_user_bought(user_id)
    
    if not has_bought:
        await callback.answer("❌ Вы можете оставить отзыв только после покупки!", show_alert=True)
        return

    await state.set_state(ReviewStates.waiting_rating)
    await callback.message.edit_text(
        "⭐ <b>Добавить отзыв</b>\n\n"
        "Выберите оценку:",
        reply_markup=get_rating_keyboard(),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("rating_"), ReviewStates.waiting_rating)
async def process_rating(callback: CallbackQuery, state: FSMContext):
    """Обработать выбранную оценку"""
    await callback.answer()
    rating = int(callback.data.split("_")[1])
    
    await state.update_data(rating=rating)
    await state.set_state(ReviewStates.waiting_text)
    
    await callback.message.edit_text(
        f"⭐ Оценка: {'⭐' * rating}\n\n"
        "📝 Напишите текст отзыва:",
        reply_markup=get_cancel_keyboard(),
        parse_mode="HTML"
    )


@router.message(ReviewStates.waiting_text)
async def process_review_text(message: Message, state: FSMContext):
    """Обработать текст отзыва"""
    text = message.text.strip()
    
    if len(text) < 10:
        await message.answer(
            "❌ Отзыв слишком короткий. Минимум 10 символов.\n"
            "Напишите отзыв еще раз:",
            reply_markup=get_cancel_keyboard()
        )
        return

    data = await state.get_data()
    rating = data.get('rating')
    
    if not rating:
        await message.answer("❌ Ошибка. Начните сначала.")
        await state.clear()
        return

    # Создать отзыв
    user_id = message.from_user.id
    review = await Database.create_review(user_id, text, rating)
    
    await message.answer(
        "✅ <b>Спасибо за отзыв!</b>\n\n"
        "Ваш отзыв добавлен и будет отображаться в списке отзывов.",
        reply_markup=get_cancel_keyboard(),
        parse_mode="HTML"
    )
    
    await state.clear()


@router.callback_query(F.data == "cancel", ReviewStates.waiting_rating)
@router.callback_query(F.data == "cancel", ReviewStates.waiting_text)
async def cancel_review(callback: CallbackQuery, state: FSMContext):
    """Отмена добавления отзыва"""
    await callback.answer("❌ Отмена")
    await state.clear()
    await show_reviews(callback)

