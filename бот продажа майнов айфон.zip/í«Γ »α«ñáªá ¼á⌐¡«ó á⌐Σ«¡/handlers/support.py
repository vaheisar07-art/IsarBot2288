from aiogram import Router, F
from aiogram.types import CallbackQuery
from database import Database
from keyboards import get_main_menu

router = Router()


@router.callback_query(F.data == "support")
async def show_support(callback: CallbackQuery):
    """Показать информацию о поддержке"""
    await callback.answer()
    
    text = (
        "💬 <b>Поддержка</b>\n\n"
        "Если у вас возникли вопросы или проблемы:\n\n"
        "👉 Напишите нам в личные сообщения - мы всегда на связи!\n\n"
        "⏰ Мы отвечаем в течение 24 часов\n\n"
        "📝 Частые вопросы:\n"
        "• После оплаты вы получите данные аккаунта\n"
        "• Используйте данные для входа в App Store\n"
        "• После скачивания игры вы можете выйти из аккаунта\n"
    )
    
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💬 Написать в поддержку", url="https://t.me/moqxm")],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_menu")]
    ])

    await callback.message.edit_text(
        text,
        reply_markup=keyboard,
        parse_mode="HTML"
    )

