from aiogram import Router, F
from aiogram.types import CallbackQuery
from database import Database
from keyboards import get_orders_list_keyboard, get_main_menu

router = Router()


@router.callback_query(F.data == "my_orders")
async def show_my_orders(callback: CallbackQuery):
    """Показать заказы пользователя"""
    await callback.answer()
    user_id = callback.from_user.id
    orders = await Database.get_user_orders(user_id)

    if not orders:
        await callback.message.edit_text(
            "📦 У вас пока нет заказов.\n\n"
            "Перейдите в каталог, чтобы сделать покупку!",
            reply_markup=get_main_menu()
        )
        return

    text = "📦 <b>Мои заказы</b>\n\n"

    status_texts = {
        "pending": "⏳ Ожидает оплаты",
        "paid": "✅ Оплачен",
        "completed": "🎉 Завершен",
        "cancelled": "❌ Отменен"
    }

    for order in orders[:10]:  # Показать последние 10 заказов
        product = await Database.get_product(order['product_id'])
        status = status_texts.get(order['status'], "❓ Неизвестно")
        
        text += f"📦 <b>Заказ #{order['id']}</b>\n"
        text += f"🎮 {product['name'] if product else 'Товар удален'}\n"
        text += f"💵 {order.get('phone_number', 'Нет')} - {product['price'] if product else 0}₽\n"
        text += f"📊 {status}\n"
        text += f"📅 {order['created_at'].strftime('%d.%m.%Y %H:%M') if order.get('created_at') else 'Нет даты'}\n\n"

    await callback.message.edit_text(
        text,
        reply_markup=get_orders_list_keyboard(orders),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("order_"))
async def show_order_details(callback: CallbackQuery):
    """Показать детали заказа"""
    await callback.answer()
    order_id = int(callback.data.split("_")[1])
    order = await Database.get_order(order_id)

    if not order or order['user_id'] != callback.from_user.id:
        await callback.answer("❌ Заказ не найден!", show_alert=True)
        return

    product = await Database.get_product(order['product_id'])
    
    status_texts = {
        "pending": "⏳ Ожидает оплаты",
        "paid": "✅ Оплачен",
        "completed": "🎉 Завершен",
        "cancelled": "❌ Отменен"
    }

    text = (
        f"📦 <b>Заказ #{order['id']}</b>\n\n"
        f"🎮 Товар: {product['name'] if product else 'Товар удален'}\n"
        f"💵 Цена: {product['price'] if product else 0}₽\n"
        f"📱 Телефон: {order['phone_number']}\n"
        f"📊 Статус: {status_texts.get(order['status'], '❓')}\n"
        f"📅 Создан: {order['created_at'].strftime('%d.%m.%Y %H:%M') if order.get('created_at') else 'Нет даты'}\n"
    )

    if order['paid_at']:
        text += f"✅ Оплачен: {order['paid_at'].strftime('%d.%m.%Y %H:%M')}\n"

    await callback.message.edit_text(
        text,
        reply_markup=get_orders_list_keyboard([order]),
        parse_mode="HTML"
    )

