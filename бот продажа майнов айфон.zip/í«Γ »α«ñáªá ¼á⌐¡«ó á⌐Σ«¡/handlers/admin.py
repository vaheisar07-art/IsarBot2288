from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.filters import Command
from database import Database
from keyboards import get_admin_menu, get_orders_list_keyboard, get_order_keyboard, get_main_menu

router = Router()


@router.message(Command("admin"))
async def admin_panel(message: Message):
    """Админ-панель"""
    user_id = message.from_user.id
    
    if not await Database.is_admin(user_id):
        await message.answer("❌ У вас нет доступа к админ-панели!")
        return

    await message.answer(
        "⚙️ <b>Админ-панель</b>\n\n"
        "Выберите действие:",
        reply_markup=get_admin_menu(),
        parse_mode="HTML"
    )


@router.callback_query(F.data == "admin_menu")
async def admin_menu(callback: CallbackQuery):
    """Показать админ-меню"""
    await callback.answer()
    if not await Database.is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа!", show_alert=True)
        return

    await callback.message.edit_text(
        "⚙️ <b>Админ-панель</b>\n\n"
        "Выберите действие:",
        reply_markup=get_admin_menu(),
        parse_mode="HTML"
    )


@router.callback_query(F.data == "admin_pending_orders")
async def show_pending_orders(callback: CallbackQuery):
    """Показать заказы ожидающие оплаты"""
    await callback.answer()
    if not await Database.is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа!", show_alert=True)
        return

    orders = await Database.get_pending_orders()

    if not orders:
        await callback.message.edit_text(
            "✅ Нет заказов ожидающих оплаты!",
            reply_markup=get_admin_menu()
        )
        return

    text = f"⏳ <b>Заказы ожидающие оплаты ({len(orders)})</b>\n\n"
    text += "Выберите заказ для просмотра и подтверждения:"

    await callback.message.edit_text(
        text,
        reply_markup=get_orders_list_keyboard(orders, is_admin=True),
        parse_mode="HTML"
    )


@router.callback_query(F.data == "admin_all_orders")
async def show_all_orders(callback: CallbackQuery):
    """Показать все заказы"""
    await callback.answer()
    if not await Database.is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа!", show_alert=True)
        return

    orders = await Database.get_all_orders()

    text = f"📋 <b>Все заказы ({len(orders)})</b>\n\n"
    text += "Выберите заказ для просмотра:"

    await callback.message.edit_text(
        text,
        reply_markup=get_orders_list_keyboard(orders, is_admin=True),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("admin_order_"))
async def show_admin_order_details(callback: CallbackQuery):
    """Показать детали заказа для админа"""
    await callback.answer()
    if not await Database.is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа!", show_alert=True)
        return

    order_id = int(callback.data.split("_")[2])
    order = await Database.get_order(order_id)

    if not order:
        await callback.answer("❌ Заказ не найден!", show_alert=True)
        return

    product = await Database.get_product(order['product_id'])
    user = await Database.get_or_create_user(order['user_id'])

    status_texts = {
        "pending": "⏳ Ожидает оплаты",
        "paid": "✅ Оплачен",
        "completed": "🎉 Завершен",
        "cancelled": "❌ Отменен"
    }

    text = (
        f"📦 <b>Заказ #{order['id']}</b>\n\n"
        f"👤 <b>Покупатель:</b>\n"
        f"   Имя: {user.get('full_name', 'Неизвестно')}\n"
        f"   Username: @{user.get('username', 'нет')}\n"
        f"   ID: {order['user_id']}\n\n"
        f"🎮 <b>Товар:</b> {product['name'] if product else 'Товар удален'}\n"
        f"💵 <b>Цена:</b> {product['price'] if product else 0}₽\n"
        f"📱 <b>Телефон:</b> {order['phone_number']}\n"
        f"📊 <b>Статус:</b> {status_texts.get(order['status'], '❓')}\n"
        f"📅 <b>Создан:</b> {order['created_at'].strftime('%d.%m.%Y %H:%M') if order.get('created_at') else 'Нет'}\n"
    )

    if order['paid_at']:
        text += f"✅ <b>Оплачен:</b> {order['paid_at'].strftime('%d.%m.%Y %H:%M')}\n"

    # Показать кнопку подтверждения только для pending заказов
    if order['status'] == 'pending':
        await callback.message.edit_text(
            text,
            reply_markup=get_order_keyboard(order_id),
            parse_mode="HTML"
        )
    else:
        await callback.message.edit_text(
            text,
            reply_markup=get_orders_list_keyboard([order], is_admin=True),
            parse_mode="HTML"
        )


@router.callback_query(F.data.startswith("admin_confirm_"))
async def confirm_payment(callback: CallbackQuery):
    """Подтвердить оплату и отправить данные"""
    await callback.answer()
    if not await Database.is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа!", show_alert=True)
        return

    order_id = int(callback.data.split("_")[2])
    order = await Database.get_order(order_id)

    if not order:
        await callback.answer("❌ Заказ не найден!", show_alert=True)
        return

    if order['status'] != 'pending':
        await callback.answer("❌ Заказ уже обработан!", show_alert=True)
        return

    # Подтвердить оплату
    await Database.confirm_payment(order_id, callback.from_user.id)

    # Получить данные аккаунта
    product = await Database.get_product(order['product_id'])
    if not product:
        await callback.answer("❌ Товар не найден!", show_alert=True)
        return

    credentials = product.get('credentials', 'Данные не указаны')

    # Отправить данные покупателю
    try:
        await callback.bot.send_message(
            order['user_id'],
            f"✅ <b>Оплата подтверждена!</b>\n\n"
            f"📦 Заказ #{order_id}\n"
            f"🎮 Товар: {product['name']}\n\n"
            f"🔐 <b>Данные аккаунта:</b>\n"
            f"{credentials}\n\n"
            f"📱 Используйте эти данные для входа в App Store и скачивания игры.",
            parse_mode="HTML"
        )
        
        # Отметить заказ как выполненный
        await Database.complete_order(order_id)

        await callback.answer("✅ Оплата подтверждена! Данные отправлены покупателю.")
        
        # Обновить сообщение админа
        order = await Database.get_order(order_id)
        if order:
            product = await Database.get_product(order['product_id'])
            user = await Database.get_or_create_user(order['user_id'])
            
            status_texts = {
                "pending": "⏳ Ожидает оплаты",
                "paid": "✅ Оплачен",
                "completed": "🎉 Завершен",
                "cancelled": "❌ Отменен"
            }
            
            text = (
                f"📦 <b>Заказ #{order['id']}</b>\n\n"
                f"👤 <b>Покупатель:</b>\n"
                f"   Имя: {user.get('full_name', 'Неизвестно')}\n"
                f"   Username: @{user.get('username', 'нет')}\n"
                f"   ID: {order['user_id']}\n\n"
                f"🎮 <b>Товар:</b> {product['name'] if product else 'Товар удален'}\n"
                f"💵 <b>Цена:</b> {product['price'] if product else 0}₽\n"
                f"📱 <b>Телефон:</b> {order['phone_number']}\n"
                f"📊 <b>Статус:</b> {status_texts.get(order['status'], '❓')}\n"
                f"📅 <b>Создан:</b> {order['created_at'].strftime('%d.%m.%Y %H:%M') if order.get('created_at') else 'Нет'}\n"
            )
            
            if order['paid_at']:
                text += f"✅ <b>Оплачен:</b> {order['paid_at'].strftime('%d.%m.%Y %H:%M')}\n"
            
            await callback.message.edit_text(
                text,
                reply_markup=get_orders_list_keyboard([order], is_admin=True),
                parse_mode="HTML"
            )
        
    except Exception as e:
        await callback.answer(f"❌ Ошибка отправки данных: {e}", show_alert=True)
        print(f"Ошибка отправки данных покупателю: {e}")

