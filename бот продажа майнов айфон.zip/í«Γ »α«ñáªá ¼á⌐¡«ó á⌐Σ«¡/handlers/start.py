from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart
from database import Database
from keyboards import get_main_menu
from config import WELCOME_TEXT

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    """Обработчик команды /start"""
    user_id = message.from_user.id
    username = message.from_user.username
    full_name = message.from_user.full_name or message.from_user.first_name

    # Создать или обновить пользователя
    await Database.get_or_create_user(user_id, username, full_name)

    await message.answer(
        WELCOME_TEXT,
        reply_markup=get_main_menu(),
        parse_mode="HTML"
    )


@router.callback_query(F.data == "back_to_menu")
async def back_to_menu(callback: CallbackQuery):
    """Возврат в главное меню"""
    await callback.answer()
    await callback.message.edit_text(
        WELCOME_TEXT,
        reply_markup=get_main_menu(),
        parse_mode="HTML"
    )

