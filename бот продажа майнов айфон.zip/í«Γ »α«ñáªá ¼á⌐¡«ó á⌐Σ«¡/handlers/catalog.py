from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from database import Database
from keyboards import get_catalog_keyboard, get_product_keyboard, get_cancel_keyboard
import asyncio

router = Router()


class OrderStates(StatesGroup):
    waiting_phone = State()


@router.callback_query(F.data == "catalog")
async def show_catalog(callback: CallbackQuery):
    """Показать каталог товаров"""
    await callback.answer()
    products = await Database.get_products()

    if not products:
        await callback.message.edit_text(
            "😔 Каталог пока пуст. Товары появятся скоро!",
            reply_markup=get_catalog_keyboard([])
        )
        return

    text = "🛍 <b>Каталог товаров</b>\n\n"
    for product in products:
        text += f"🎮 <b>{product['name']}</b>\n"
        text += f"💵 Цена: {product['price']}₽\n"
        if product.get('description'):
            text += f"📝 {product['description']}\n"
        text += "\n"

    await callback.message.edit_text(
        text,
        reply_markup=get_catalog_keyboard(products),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("buy_"))
async def buy_product(callback: CallbackQuery, state: FSMContext):
    """Начать покупку товара"""
    await callback.answer()
    product_id = int(callback.data.split("_")[1])
    product = await Database.get_product(product_id)

    if not product:
        await callback.message.edit_text("❌ Товар не найден!")
        return

    # Сохранить product_id в состоянии
    await state.update_data(product_id=product_id)
    await state.set_state(OrderStates.waiting_phone)

    await callback.message.edit_text(
        f"🎮 <b>Покупка: {product['name']}</b>\n\n"
        f"💵 Цена: {product['price']}₽\n\n"
        "📱 <b>Отправьте номер телефона для перевода:</b>\n"
        "(Например: +79001234567 или 89001234567)",
        reply_markup=get_cancel_keyboard(),
        parse_mode="HTML"
    )


@router.message(OrderStates.waiting_phone)
async def process_phone(message: Message, state: FSMContext):
    """Обработка введенного номера телефона"""
    phone = message.text.strip()

    # Простая валидация номера
    phone_clean = phone.replace("+", "").replace("-", "").replace(" ", "").replace("(", "").replace(")", "")
    if not phone_clean.isdigit() or len(phone_clean) < 10:
        await message.answer(
            "❌ Некорректный номер телефона. Попробуйте еще раз:",
            reply_markup=get_cancel_keyboard()
        )
        return

    data = await state.get_data()
    product_id = data.get("product_id")
    product = await Database.get_product(product_id)

    if not product:
        await message.answer("❌ Ошибка: товар не найден!")
        await state.clear()
        return

    # Создать заказ
    user_id = message.from_user.id
    order = await Database.create_order(user_id, product_id, phone)

    # Уведомить пользователя
    await message.answer(
        f"✅ <b>Заказ создан!</b>\n\n"
        f"📦 Номер заказа: #{order['id']}\n"
        f"🎮 Товар: {product['name']}\n"
        f"💵 Сумма: {product['price']}₽\n"
        f"📱 Номер для перевода: {phone}\n\n"
        f"⏳ Ожидайте подтверждения оплаты администратором.\n"
        f"После подтверждения вы получите данные аккаунта.",
        reply_markup=get_cancel_keyboard(),
        parse_mode="HTML"
    )

    # Уведомить администраторов
    await notify_admins_new_order(order, product, message.bot)

    await state.clear()


@router.callback_query(F.data == "cancel")
async def cancel_action(callback: CallbackQuery, state: FSMContext):
    """Отмена действия"""
    await callback.answer("❌ Действие отменено")
    await state.clear()
    await callback.message.edit_text(
        "Действие отменено. Используйте /start для возврата в меню."
    )


async def notify_admins_new_order(order: dict, product: dict, bot_instance):
    """Уведомить администраторов о новом заказе"""
    from database import Database

    admin_ids = await Database.get_admin_ids()
    user = await Database.get_or_create_user(order['user_id'])

    text = (
        f"🔔 <b>Новый заказ!</b>\n\n"
        f"📦 Заказ #{order['id']}\n"
        f"👤 Пользователь: {user.get('full_name', 'Неизвестно')}\n"
        f"   Username: @{user.get('username', 'нет')}\n"
        f"   ID: {order['user_id']}\n"
        f"🎮 Товар: {product['name']}\n"
        f"💵 Цена: {product['price']}₽\n"
        f"📱 Телефон: {order['phone_number']}\n\n"
        f"Используйте /admin для управления заказами"
    )

    for admin_id in admin_ids:
        try:
            await bot_instance.send_message(admin_id, text, parse_mode="HTML")
        except Exception as e:
            print(f"Ошибка отправки уведомления админу {admin_id}: {e}")

